A Pen created at CodePen.io. You can find this one at http://codepen.io/marinda-s/pen/dtehw.

 Sass pattern mixin with CSS background-blend-mode